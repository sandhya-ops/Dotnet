﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee o1 = new Employee("Amol", 123465, 10);
            o1.Auto();
            Console.WriteLine(o1.EmpNo+" "+o1.Name+" "+o1.Basic+" "+o1.DeptNo);
            Employee o2 = new Employee("Amol", 123465);
            o2.Auto();
            Console.WriteLine(o2.EmpNo+" "+o2.Name+" "+o2.Basic+" "+o2.DeptNo);
            
            Employee o3 = new Employee("Amol");
            o3.Auto();
            Console.WriteLine(o3.EmpNo+" "+o3.Name+" "+o3.Basic+" "+o3.DeptNo);
            Employee o4 = new Employee();
            o4.Auto();
            Console.WriteLine(o4.EmpNo);
            Console.ReadLine();
        }
    }

    class Employee
    {
        string name;
        public string Name 
        {
            set 
            {
                name = value;
                empNo+=1;
            }
            get 
            {
                return name;
            }
        }

        static int auto;
        int empNo;
        public int Auto()
        {
            auto++;
            empNo = auto;
            return empNo;
        }
        public int EmpNo
        {
            get
            {
                return empNo;
            }
        }

        double basic;
        public double Basic
        {
            set
            {
                basic = value;
            }
            get 
            {
                return basic;
            }
        }

        short deptNo;
        public short DeptNo
        {
            set
            {
                deptNo = value;
            }
            get 
            {
                return deptNo;
            }
        }
        double GetNetSalary() {
            double netSalary;
            netSalary = Basic * 12;
            return netSalary;
        }
        public Employee()
        {
        }
        public Employee(string name)
        {
            this.name = name;
        }
        public Employee(string name, double basic)
        {
            this.name = name;
            this.basic = basic;
        }
        public Employee(string name, double basic, short deptNo)
        {
            this.name = name;
            this.basic = basic;
            this.deptNo = deptNo;
        }

    }
}
